package Project;

import javafx.fxml.FXML;
import javafx.scene.control.RadioButton;
import javafx.scene.control.Label;
import javafx.scene.control.Button;
import javafx.stage.Stage;
import javafx.fxml.FXMLLoader;
import javafx.scene.Scene;
import java.util.ArrayList;
import java.util.Date;
import javax.swing.JOptionPane;

public class ChooseParkingSpotController {

    // RadioButtons for parking spots
    @FXML
    private RadioButton A1, A2, A3, A4, A5, B1, B2, B3, B4, B5, C1, C2, C3, C4, C5;

    // Label to display error messages
    @FXML
    private Label errorLabel1;

    // Buttons for choosing a spot and navigating back
    @FXML
    private Button chooseSpotButton, backButton2;

    // Variables to store reservation details
    private String carPlateNumber;
    private String carPlateCharacters;
    private int duration;

    // Set car plate and reservation details passed from previous screen
    public void setCarPlateDetails(String carPlateNumber, String carPlateCharacters, int duration) {
        this.carPlateNumber = carPlateNumber;
        this.carPlateCharacters = carPlateCharacters;
        this.duration = duration;
    }

    @FXML
    public void initialize() {
        // Disable already reserved spots based on reservations loaded from file
        ArrayList<Reservation> reservations = ReservationFileUtil.loadReservations();
        for (Reservation reservation : reservations) {
            disableReservedSpot(reservation.getSpotId());
        }
    }

    @FXML
    private void handleChooseSpotButton() {
        // Check if a parking spot is selected
        RadioButton selectedSpot = getSelectedSpot();
        if (selectedSpot != null) {
            // Create and save the reservation
            Date reservationTime = new Date();
            Reservation reservation = new Reservation(carPlateNumber, carPlateCharacters, selectedSpot.getId(), reservationTime, duration);
            ReservationFileUtil.addReservation(reservation);

            // Disable the selected spot and display success message
            disableReservedSpot(selectedSpot.getId());
            errorLabel1.setText("Reservation successful!");
            JOptionPane.showMessageDialog(null, "Reservation successful!");
            System.exit(0);  // Close the application after reserving
        } else {
            // Show error message if no spot is selected
            errorLabel1.setText("Please select a parking spot.");
        }
    }

    // Helper method to get the selected parking spot
    private RadioButton getSelectedSpot() {
        if (A1.isSelected()) return A1;
        if (A2.isSelected()) return A2;
        if (A3.isSelected()) return A3;
        if (A4.isSelected()) return A4;
        if (A5.isSelected()) return A5;
        if (B1.isSelected()) return B1;
        if (B2.isSelected()) return B2;
        if (B3.isSelected()) return B3;
        if (B4.isSelected()) return B4;
        if (B5.isSelected()) return B5;
        if (C1.isSelected()) return C1;
        if (C2.isSelected()) return C2;
        if (C3.isSelected()) return C3;
        if (C4.isSelected()) return C4;
        if (C5.isSelected()) return C5;
        return null;
    }

    // Helper method to disable a reserved spot and change its color to red
    private void disableReservedSpot(String spotId) {
        RadioButton spot = getSpotById(spotId);
        if (spot != null) {
            spot.setDisable(true);
            spot.setStyle("-fx-text-fill: red;");  // Set text color to red
        }
    }

    // Helper method to enable a spot and reset its color to black (if needed)
    private void enableSpot(String spotId) {
        RadioButton spot = getSpotById(spotId);
        if (spot != null) {
            spot.setDisable(false);
            spot.setStyle("-fx-text-fill: black;");  // Reset text color to default
        }
    }

    // Helper method to get a RadioButton by its ID
    private RadioButton getSpotById(String spotId) {
        switch (spotId) {
            case "A1": return A1;
            case "A2": return A2;
            case "A3": return A3;
            case "A4": return A4;
            case "A5": return A5;
            case "B1": return B1;
            case "B2": return B2;
            case "B3": return B3;
            case "B4": return B4;
            case "B5": return B5;
            case "C1": return C1;
            case "C2": return C2;
            case "C3": return C3;
            case "C4": return C4;
            case "C5": return C5;
            default: return null;
        }
    }

    @FXML
    private void handleBackButton() {
        // Navigate back to the Reservation Details screen
        try {
            Stage stage = (Stage) backButton2.getScene().getWindow();
            FXMLLoader loader = new FXMLLoader(getClass().getResource("Reservation Details.fxml"));
            Scene scene = new Scene(loader.load());
            stage.setScene(scene);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}
