package Project;

import javafx.fxml.FXML;
import javafx.scene.control.ComboBox;
import javafx.scene.control.Label;
import javafx.scene.control.Button;
import javafx.stage.Stage;
import javafx.fxml.FXMLLoader;
import javafx.scene.Scene;
import javax.swing.JOptionPane;
import java.util.ArrayList;
import java.util.Date;

public class CancelReservationController {

    // ComboBoxes for entering car plate number and characters
    @FXML
    private ComboBox<String> num1, num2, num3, num4, char1, char2, char3;

    // Label to display error messages
    @FXML
    private Label errorLabel2;

    // Buttons for confirming cancellation and navigating back
    @FXML
    private Button confirmCancelationButton, backButton3;

    @FXML
    public void initialize() {
        // Populate ComboBoxes for numbers (0-9)
        for (int i = 0; i <= 9; i++) {
            String number = String.valueOf(i);
            num1.getItems().add(number);
            num2.getItems().add(number);
            num3.getItems().add(number);
            num4.getItems().add(number);
        }

        // Populate ComboBoxes for characters (A-Z)
        for (char c = 'A'; c <= 'Z'; c++) {
            String letter = String.valueOf(c);
            char1.getItems().add(letter);
            char2.getItems().add(letter);
            char3.getItems().add(letter);
        }
    }

    @FXML
    private void handleConfirmCancelationButton() {
        // Check if all fields are filled
        if (num1.getValue() == null || num2.getValue() == null || num3.getValue() == null || num4.getValue() == null ||
            char1.getValue() == null || char2.getValue() == null || char3.getValue() == null) {
            errorLabel2.setText("Please select all values."); // Show error if any field is empty
            return;
        }

        // Construct car plate details from ComboBox values
        String carPlateNumber = num1.getValue() + num2.getValue() + num3.getValue() + num4.getValue();
        String carPlateCharacters = char1.getValue() + char2.getValue() + char3.getValue();

        // Load reservations from the file
        ArrayList<Reservation> reservations = ReservationFileUtil.loadReservations();

        // If no reservations exist, display an error
        if (reservations.isEmpty()) {
            errorLabel2.setText("No reservations found.");
            return;
        }

        // Search for the matching reservation
        boolean found = false;
        for (Reservation reservation : reservations) {
            if (reservation.getCarPlateNumber().equals(carPlateNumber) &&
                reservation.getCarPlateCharacters().equals(carPlateCharacters)) {
                found = true;

                // Calculate time difference to check if the reservation has exceeded its duration
                long currentTime = new Date().getTime();
                long reservationTime = reservation.getReservationTime().getTime();
                long elapsedTimeInMinutes = (currentTime - reservationTime) / (1000 * 60);

                // If the reservation time is exceeded, show a fine message
                if (elapsedTimeInMinutes > reservation.getDuration()) {
                    long fineMinutes = elapsedTimeInMinutes - reservation.getDuration();
                    JOptionPane.showMessageDialog(null, "Reservation canceled with a fine. Extra minutes: " + fineMinutes);
                    
                } else {
                    JOptionPane.showMessageDialog(null, "Reservation canceled successfully.");
                    
                }

                // Remove the reservation from the file
                ReservationFileUtil.removeReservation(carPlateNumber, carPlateCharacters);
                errorLabel2.setText("Reservation canceled successfully.");
               
                break;
            }
        }

        // If no matching reservation is found, display an error
        if (!found) {
            errorLabel2.setText("No reservation found with that car plate.");
        }
    }

    @FXML
    private void handleBackButton() {
        // Navigate back to the main menu
        try {
            Stage stage = (Stage) backButton3.getScene().getWindow();
            FXMLLoader loader = new FXMLLoader(getClass().getResource("MainMenu.fxml"));
            Scene scene = new Scene(loader.load());
            stage.setScene(scene);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}
