package Project;

import javafx.fxml.FXML;
import javafx.scene.control.Button;
import javafx.scene.control.ComboBox;
import javafx.scene.control.Label;
import javafx.stage.Stage;
import javafx.fxml.FXMLLoader;
import javafx.scene.Scene;
import javafx.scene.Parent;

public class ReservationDetailsController {

    // ComboBoxes for entering car plate details and selecting reservation time
    @FXML
    private ComboBox<String> n1, n2, n3, n4, ch1, ch2, ch3, timeComboBox;

    // Buttons for submitting reservation and navigating back
    @FXML
    private Button submitButton, backButton1;

    // Label to display error messages
    @FXML
    private Label errorLabel;

    @FXML
    public void initialize() {
        // Populate ComboBoxes with numbers (0-9)
        for (int i = 0; i <= 9; i++) {
            String number = String.valueOf(i);
            n1.getItems().add(number);
            n2.getItems().add(number);
            n3.getItems().add(number);
            n4.getItems().add(number);
        }

        // Populate ComboBoxes with characters (A-Z)
        for (char c = 'A'; c <= 'Z'; c++) {
            String letter = String.valueOf(c);
            ch1.getItems().add(letter);
            ch2.getItems().add(letter);
            ch3.getItems().add(letter);
        }

        // Populate timeComboBox with reservation durations
        if (timeComboBox != null) {
            timeComboBox.getItems().add("30 min");
            timeComboBox.getItems().add("1 hr");
            timeComboBox.getItems().add("1 hr 30 min");
            timeComboBox.getItems().add("2 hr");
        }
    }

    @FXML
    private void handleSubmitButton() {
        // Validate input and proceed if valid
        if (isInputValid()) {
            errorLabel.setText(""); // Clear error message

            // Collect car plate details and duration
            String carPlateNumber = n1.getValue() + n2.getValue() + n3.getValue() + n4.getValue();
            String carPlateCharacters = ch1.getValue() + ch2.getValue() + ch3.getValue();
            int duration = convertTimeToMinutes(timeComboBox.getValue());

            // Navigate to Choose Parking Spot screen
            navigateToChooseParkingSpot(carPlateNumber, carPlateCharacters, duration);
        } else {
            // Show error if input is incomplete
            errorLabel.setText("Please fill out all fields.");
        }
    }

    // Check if all fields are filled
    private boolean isInputValid() {
        return n1.getValue() != null && n2.getValue() != null &&
               n3.getValue() != null && n4.getValue() != null &&
               ch1.getValue() != null && ch2.getValue() != null &&
               ch3.getValue() != null && timeComboBox.getValue() != null;
    }

    // Convert time from string to minutes
    private int convertTimeToMinutes(String time) {
        switch (time) {
            case "30 min": return 30;
            case "1 hr": return 60;
            case "1 hr 30 min": return 90;
            case "2 hr": return 120;
            default: return 0;
        }
    }

    // Navigate to Choose Parking Spot screen
    private void navigateToChooseParkingSpot(String carPlateNumber, String carPlateCharacters, int duration) {
        try {
            // Load the ChooseParkingSpot.fxml file
            FXMLLoader loader = new FXMLLoader(getClass().getResource("ChooseParkingSpot.fxml"));
            Parent root = loader.load();

            // Pass car plate details to the next screen
            ChooseParkingSpotController controller = loader.getController();
            controller.setCarPlateDetails(carPlateNumber, carPlateCharacters, duration);

            // Change to the new scene
            Stage stage = (Stage) submitButton.getScene().getWindow();
            stage.setScene(new Scene(root));
            stage.show();
        } catch (Exception e) {
            e.printStackTrace(); // Print error if loading fails
        }
    }

    @FXML
    private void handleBackButton() {
        // Navigate back to the Main Menu screen
        try {
            Stage stage = (Stage) backButton1.getScene().getWindow();
            FXMLLoader loader = new FXMLLoader(getClass().getResource("MainMenu.fxml"));
            Scene scene = new Scene(loader.load());
            stage.setScene(scene);
        } catch (Exception e) {
            e.printStackTrace(); // Print error if loading fails
        }
    }
}
