package Project;

import java.io.*;
import java.util.ArrayList;

/**
 * Utility class for handling reservation file operations.
 */
public class ReservationFileUtil {
    private static final String FILE_NAME = "reservations.dat"; // File name for storing reservations

    // Saves the list of reservations to a file
    public static void saveReservations(ArrayList<Reservation> reservations) {
        try (ObjectOutputStream out = new ObjectOutputStream(new FileOutputStream(FILE_NAME))) {
            out.writeObject(reservations); // Write the list of reservations to the file
        } catch (IOException e) {
            e.printStackTrace(); // Print error if save fails
        }
    }

    // Loads the list of reservations from the file
    public static ArrayList<Reservation> loadReservations() {
        ArrayList<Reservation> reservations = new ArrayList<>();
        try (ObjectInputStream in = new ObjectInputStream(new FileInputStream(FILE_NAME))) {
            reservations = (ArrayList<Reservation>) in.readObject(); // Read reservations from the file
        } catch (FileNotFoundException e) {
            // If the file does not exist, return an empty list
            System.out.println("File not found. A new file will be created.");
        } catch (IOException | ClassNotFoundException e) {
            e.printStackTrace(); // Print error if load fails
        }
        return reservations;
    }

    // Adds a new reservation to the file
    public static void addReservation(Reservation reservation) {
        ArrayList<Reservation> reservations = loadReservations(); // Load existing reservations
        reservations.add(reservation); // Add the new reservation
        saveReservations(reservations); // Save the updated list
    }

    // Removes a reservation from the file based on car plate details
    public static void removeReservation(String carPlateNumber, String carPlateCharacters) {
        ArrayList<Reservation> reservations = loadReservations(); // Load existing reservations
        for (int i = 0; i < reservations.size(); i++) {
            Reservation reservation = reservations.get(i);
            // Find the matching reservation and remove it
            if (reservation.getCarPlateNumber().equals(carPlateNumber) &&
                reservation.getCarPlateCharacters().equals(carPlateCharacters)) {
                reservations.remove(i);
                break;
            }
        }
        saveReservations(reservations); // Save the updated list
    }
}
