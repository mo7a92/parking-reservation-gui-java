package Project;

import javafx.fxml.FXML;
import javafx.scene.control.Button;
import javafx.stage.Stage;
import javax.swing.JOptionPane;
import javafx.fxml.FXMLLoader;
import javafx.scene.Scene;

public class MainMenuController {

    // Buttons for navigating to other screens and displaying information
    @FXML
    private Button cancelButton, reserveButton, infoButton, helpButton;

    @FXML
    private void handleInfoButton() {
        // Display information about the app
        JOptionPane.showMessageDialog(null, "This app is for reserving parking spots.");
    }

    @FXML
    private void handleHelpButton() {
        // Display help contact information
        JOptionPane.showMessageDialog(null, "For help, contact: help@uj.edu.sa");
    }

    @FXML
    private void handleReserveButton() {
        // Navigate to the Reservation Details screen
        navigateTo("Reservation Details.fxml");
    }

    @FXML
    private void handleCancelButton() {
        // Navigate to the Cancel Reservation screen
        navigateTo("Cancel Reservation.fxml");
    }


    // Helper method to switch between scenes
    private void navigateTo(String fxmlFile) {
        try {
            // Get the current stage from the reserve button's scene
            Stage stage = (Stage) reserveButton.getScene().getWindow();
            stage.close(); // Close the current window

            // Load the new scene from the specified FXML file
            FXMLLoader loader = new FXMLLoader(getClass().getResource(fxmlFile));
            Stage newStage = new Stage();
            newStage.setScene(new Scene(loader.load()));
            newStage.show(); // Show the new window
        } catch (Exception e) {
            // Print stack trace if an error occurs during scene loading
            e.printStackTrace();
        }
    }
}
