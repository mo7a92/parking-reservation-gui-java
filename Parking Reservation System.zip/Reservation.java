package Project;

import java.io.Serializable;
import java.util.Date;

/**
 * A class to store details about a parking reservation.
 */
public class Reservation implements Serializable {
    private static final long serialVersionUID = 1L; // For serialization compatibility

    private String carPlateNumber;    // Car plate number (numbers)
    private String carPlateCharacters; // Car plate letters
    private String spotId;           // Parking spot ID
    private Date reservationTime;    // Reservation time
    private int duration;            // Duration in minutes

   
    public Reservation(String carPlateNumber, String carPlateCharacters, String spotId, Date reservationTime, int duration) {
        this.carPlateNumber = carPlateNumber;
        this.carPlateCharacters = carPlateCharacters;
        this.spotId = spotId;
        this.reservationTime = reservationTime;
        this.duration = duration;
    }

    // Getters to access reservation details
    public String getCarPlateNumber() {
        return carPlateNumber;
    }

    public String getCarPlateCharacters() {
        return carPlateCharacters;
    }

    public String getSpotId() {
        return spotId;
    }

    public Date getReservationTime() {
        return reservationTime;
    }

    public int getDuration() {
        return duration;
    }
}
